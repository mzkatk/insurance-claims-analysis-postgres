-- Task 1 : Database Schema Creation
-- Define tables: Customers, policies, Claims, PolicyTypes.
   -- Include fields such as CustomerId, PolicyID, ClaimID, PolicyTypeID ClaimAmount, ClaimDate
   -- PolicyStartDate, PolicyEndDate, etc.

--Customers Table---

create table Customers(
   CustomerID SERIAL primary key,
   FirstName varchar(255),
   LastName varchar(255),
   DateOfBirth DATE,
   Gender CHAR(1),
   Address varchar(255),
   City varchar(100),
   State varchar(50),
   ZipCode varchar(10)
);




--PolicyTypes Table--

create table PolicyTypes (
   PolicyTypeID serial primary key,
   PolicyTypeName varchar(50),
   Description TEXT
);




---Policies Table---

create table Policies(
   PolicyID SERIAL PRIMARY KEY,
   CustomerID INT REFERENCES Customers(CustomerID),
   PolicyTypeID INT REFERENCES PolicyTypes(PolicyTypeID),
   PolicyStartDate DATE,
   PolicyEndDate DATE,
   Premium DECIMAL(10,2)
);

---Claims Table---

CREATE TABLE Claims (
    ClaimID SERIAL PRIMARY KEY,
    PolicyID INT REFERENCES Policies(PolicyID),
    ClaimDate DATE,
    ClaimAmount DECIMAL(10,2),
    ClaimDescription TEXT,
    ClaimStatus VARCHAR(50)
);
