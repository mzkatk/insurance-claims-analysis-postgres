# insurance-claims-analysis-postgres(PostgreSQL)

This project analyzes insurance claims using SQL...

## Project Structure

- `/schema/schema.sql` → Creates tables like Customers, Policies
- `/data/sample_data.sql` → Adds sample data
- `/queries/analysis_queries.sql` → Analytics queries